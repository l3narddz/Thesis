
<!DOCTYPE html>
<html>
<head>
    <title>Home</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="images/favicon.png">

    <script type="text/javascript" src="js/jquery-2.2.3.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.js"></script>


    </script>
</head>
<body>
<?php include'header.php'; ?>

<form action="/action_page.php">
  <label for="fname">First name:</label>
  <input type="text" id="fname" name="fname"><br><br>
  <label for="lname">Last name:</label>
  <input type="text" id="lname" name="lname"><br><br>
</form><input type="date" name="date_sel_start" id="date_sel_start">
<input type="submit" value="Submit">

<p>Click the "Submit" button and the form-data will be sent to a page on the
server called "action_page.php".</p>
